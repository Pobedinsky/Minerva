package com.example.minerva;

public class User {

    private int valx;
    private double valy;

    public User(int valx,double valy) {
        this.valx = valx;
        this.valy = valy;
    }

    public int getValx(){
        return valx;
    }

    public double getValy(){
        return valy;
    }
}
